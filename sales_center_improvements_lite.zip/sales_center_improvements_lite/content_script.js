window.addEventListener('load', async () => {
	console.log('Załadowano skrypt salesCenterImprovementsLite');	
  let toast;
  toast = document.getElementById('aeToast');
  if (toast === null) {
    toast = document.createElement('div');
    toast.id = 'aeToast';
    toast.classList.add('aeToastHidden');
    document.body.appendChild(toast);
  }

  let messageIcon, topMessageIcon;
  try {
    messageIcon = await waitForMenu();
  } catch (error) {
    toastMessage(`Błąd! ${error instanceof Error ? error.message : error }`);
    return;
  }

  topMessageIcon = messageIcon[0];
  messageIcon = messageIcon[1];

  const topIconMutationObserver = new MutationObserver(mutations => {
    mutations.forEach(async (mutation) => {
      if (mutation.removedNodes.length) {
        const messageIconBadge = messageIcon.querySelector('#messageIconBadge');
        if (messageIconBadge) messageIconBadge.remove();
      } else {
        let messageIconBadge;
        messageIconBadge = messageIcon.querySelector('#messageIconBadge');
        if (!messageIconBadge) {
          messageIconBadge = document.createElement('div');
          messageIconBadge.id = 'messageIconBadge';
          messageIconBadge.className = (mutation.type === 'characterData' ? mutation.target.parentNode.className : mutation.target.children[1].className);
          messageIconBadge.classList.remove('mp7g_f6');
          messageIconBadge.textContent = (mutation.type === 'characterData' ? mutation.target.textContent : mutation.target.children[1].textContent);
          messageIcon.firstChild.firstChild.insertAdjacentElement('afterend', messageIconBadge);
        } else {
          messageIconBadge.textContent = (mutation.type === 'characterData' ? mutation.target.textContent : mutation.target.children[1].textContent);
        }
      }      
    });
  });

  if (topMessageIcon.parentElement.textContent !== '') {
    let messageIconBadge = document.createElement('div');
    messageIconBadge.id = 'messageIconBadge';
    messageIconBadge.className = topMessageIcon.nextElementSibling.className;
    messageIconBadge.classList.remove('mp7g_f6');
    messageIconBadge.textContent = topMessageIcon.nextElementSibling.textContent;
    messageIcon.firstChild.firstChild.insertAdjacentElement('afterend', messageIconBadge); 
  }

  topIconMutationObserver.observe(topMessageIcon.parentElement, { childList: true, subtree: true, characterData: true });
});

async function waitForMenu(retry = 10) {
  let messageIcon = document.querySelectorAll('a[href="/message-center/messages"]');

  if (!messageIcon) {
    if (--retry) {
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      await delay(5000);
      return await waitForMenu(retry);
    } else {
      return Promise.reject('Nie znaleziono menu bocznego. Rozszerzenie nie będzie działać.');  
    }
  } else {
    return Promise.resolve(messageIcon);
  }
}

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
  switch (action) {
    case 'toast': {
      toastMessage(request.message);
      break;
    }
  }
}