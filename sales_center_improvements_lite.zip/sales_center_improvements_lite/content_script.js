window.addEventListener('load', async () => {
	console.log('Załadowano skrypt salesCenterImprovementsLite');	
  let toast;
  toast = document.getElementById('aeToast');
  if (toast === null) {
    toast = document.createElement('div');
    toast.id = 'aeToast';
    toast.classList.add('aeToastHidden');
    document.body.appendChild(toast);
  }
  let messageIcons, drawerMessageIcon, topDiscussionIcon, topMessageIcon, drawerOrdersAndReturnsIcon;

  try {
    [ messageIcons, topDiscussionIcon, drawerOrdersAndReturnsIcon ] = await waitForMenu();
  } catch (error) {
    toastMessage(`Błąd! ${error instanceof Error ? error.message : error}`);
    return;
  }

  topMessageIcon = messageIcons[0];
  drawerMessageIcon = messageIcons[1];

  const drawer = document.querySelector('header[data-testid="drawer-menu"]');
  if (!drawer) {
    toastMessage('Błąd! Nie znaleziono menu bocznego. Rozszerzenie nie będzie działać.');
    return;
  }
  drawer.addEventListener('transitionend', (e) => {
    if (e.propertyName === 'width') {
      const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
      let discussionIconBadge = drawer.querySelector('#discussionIconBadge');
      if (discussionIconBadge) discussionIconBadge.remove();
      if (topDiscussionIcon.nextElementSibling !== null) {
        discussionIconBadge = document.createElement('div');
        discussionIconBadge.id = 'discussionIconBadge';
        discussionIconBadge.className = topDiscussionIcon.nextElementSibling.className;
        discussionIconBadge.classList.remove('mp7g_f6');
        discussionIconBadge.textContent = topDiscussionIcon.nextElementSibling.textContent;

        if (drawer.offsetWidth > 100) {
          if (discussionMenu) {
            discussionIconBadge.classList.add('badgeMoved'); 
            discussionMenu.before(discussionIconBadge);
          } else {
            drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
          }   
        } else {
          drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
        }
      }
    }
  });

  const mutationObserver = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.type === 'attributes' && mutation.attributeName === 'aria-expanded') {
        const isExpanded = drawerOrdersAndReturnsIcon.getAttribute('aria-expanded') === 'true';

        let discussionIconBadge = drawer.querySelector('#discussionIconBadge');
        if (discussionIconBadge) discussionIconBadge.remove();
        if (topDiscussionIcon.nextElementSibling !== null) {
          discussionIconBadge = document.createElement('div');
          discussionIconBadge.id = 'discussionIconBadge';
          discussionIconBadge.className = topDiscussionIcon.nextElementSibling.className;
          discussionIconBadge.classList.remove('mp7g_f6');
          discussionIconBadge.textContent = topDiscussionIcon.nextElementSibling.textContent;

          if (isExpanded) {
            const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
            discussionIconBadge.classList.add('badgeMoved');
            discussionMenu.before(discussionIconBadge);       
          } else {
            drawerOrdersAndReturnsIcon.querySelector('p').style.setProperty('background', 'none', 'important');
            drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge); 
          }
        }
      }
    });
  });
  mutationObserver.observe(drawerOrdersAndReturnsIcon, { attributes: true, attributeFilter: ['aria-expanded'] }); 

  const topMessageIconMutationObserver = new MutationObserver(mutations => {
    mutations.forEach(async (mutation) => {
      if (mutation.removedNodes.length) {
        const messageIconBadge = drawerMessageIcon.querySelector('#messageIconBadge');
        if (messageIconBadge) messageIconBadge.remove();
      } else {
        let messageIconBadge;
        messageIconBadge = drawerMessageIcon.querySelector('#messageIconBadge');
        if (!messageIconBadge) {
          if (topMessageIcon.nextElementSibling !== null) {
            messageIconBadge = document.createElement('div');
            messageIconBadge.id = 'messageIconBadge';
            messageIconBadge.className = topMessageIcon.nextElementSibling.className;
            messageIconBadge.classList.remove('mp7g_f6');
            messageIconBadge.textContent = topMessageIcon.nextElementSibling.textContent;
            drawerMessageIcon.firstChild.firstChild.after(messageIconBadge);
          }
        } else {
          messageIconBadge.textContent = topMessageIcon.nextElementSibling.textContent;
        }
      }
    });
  });

  if (topMessageIcon.nextElementSibling !== null) {
    let messageIconBadge = document.createElement('div');
    messageIconBadge.id = 'messageIconBadge';
    messageIconBadge.className = topMessageIcon.nextElementSibling.className;
    messageIconBadge.classList.remove('mp7g_f6');
    messageIconBadge.textContent = topMessageIcon.nextElementSibling.textContent;
    drawerMessageIcon.firstChild.firstChild.after(messageIconBadge); 
  }

  const topDiscussionIconMutationObserver = new MutationObserver(mutations => {
    mutations.forEach(async (mutation) => {
      if (mutation.removedNodes.length) {
        const discussionIconBadge = drawer.querySelector('#discussionIconBadge');
        if (discussionIconBadge) discussionIconBadge.remove();
      } else {
        let discussionIconBadge;
        discussionIconBadge = drawer.querySelector('#discussionIconBadge');
        if (!discussionIconBadge) {
          if (topDiscussionIcon.nextElementSibling !== null) {
            discussionIconBadge = document.createElement('div');
            discussionIconBadge.id = 'discussionIconBadge';
            discussionIconBadge.className = topDiscussionIcon.nextElementSibling.className;
            discussionIconBadge.classList.remove('mp7g_f6');
            discussionIconBadge.textContent = topDiscussionIcon.nextElementSibling.textContent;
            const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
            if (drawer.offsetWidth > 100) {
              if (discussionMenu) {
                discussionIconBadge.classList.add('badgeMoved'); 
                discussionMenu.before(discussionIconBadge);
              } else drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
            } else {
              drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
            }
          }
        } else {
          if (topDiscussionIcon.nextElementSibling !== null) {
            discussionIconBadge.textContent = topDiscussionIcon.nextElementSibling.textContent;
          }
        }
      }
    });
  });

  if (topDiscussionIcon.nextElementSibling !== null) {
    let discussionIconBadge = document.createElement('div');
    discussionIconBadge.id = 'discussionIconBadge';
    discussionIconBadge.className = topDiscussionIcon.nextElementSibling.className;
    discussionIconBadge.classList.remove('mp7g_f6');
    discussionIconBadge.textContent = topDiscussionIcon.nextElementSibling.textContent;
    const discussionMenu = drawer.querySelector('a[href="/discussions-with-buyers"]');
    if (drawer.offsetWidth > 100) {
      if (discussionMenu) {
        discussionIconBadge.classList.add('badgeMoved'); 
        discussionMenu.before(discussionIconBadge);
      } else drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
    } else {
      drawerOrdersAndReturnsIcon.firstChild.firstChild.after(discussionIconBadge);
    }
  }

  topMessageIconMutationObserver.observe(topMessageIcon.parentElement, { childList: true, subtree: true, characterData: true });
  topDiscussionIconMutationObserver.observe(topDiscussionIcon.parentElement, { childList: true, subtree: true, characterData: true });
});

async function waitForMenu(retry = 10) {
  const topBar = document.querySelector('div[data-box-name="allegro.salescenter.bar"]');
  if (!topBar) {
    if (--retry) {
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      await delay(5000);
      return await waitForMenu(retry);
    } else {
      return Promise.reject('Nie znaleziono górnego menu. Rozszerzenie nie będzie działać.');  
    }
  }

  let messageIcons = document.querySelectorAll('a[href="/message-center/messages"]');
  let topDiscussionIcon = topBar.querySelector('a[href="/discussions-with-buyers"]');
  let drawerOrdersAndReturnsIcon = document.querySelector('button[aria-controls="ordersAndReturns"]');

  if (!messageIcons || !topDiscussionIcon || !drawerOrdersAndReturnsIcon) {
    if (--retry) {
      const delay = t => new Promise(resolve => setTimeout(resolve, t));
      await delay(5000);
      return await waitForMenu(retry);
    } else {
      return Promise.reject('Nie znaleziono ikon. Rozszerzenie nie będzie działać.');  
    }
  } else {
    return Promise.resolve([messageIcons, topDiscussionIcon, drawerOrdersAndReturnsIcon]);
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
  switch (action) {
    case 'toast': {
      toastMessage(request.message);
      return Promise.resolve(true);
    }
  }
}