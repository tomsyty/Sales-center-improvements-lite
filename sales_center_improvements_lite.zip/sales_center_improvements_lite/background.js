async function sendMessage(tab, data) {
	return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tab, data, (response) => {
      chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response); 
	  });
  });
}

(function main() {
  console.log('Załadowano rozszerzenie Sales Center Improvements Lite');

  (async () => {
		for (const contentScript of chrome.runtime.getManifest().content_scripts) {
			for (const tab of await chrome.tabs.query({ url: contentScript.matches })) {
				try {
					chrome.scripting.insertCSS({
						target: { tabId: tab.id },
						files: contentScript.css
					});
					chrome.scripting.executeScript({
						target: { tabId: tab.id },
						files: contentScript.js
					});
					console.log('odświeżono skrypty na otwartych stronach.');					
				} catch (error) {
					showMessageFromBackground('Błąd! Nie udało się odświeżyć skryptów.');
				}
			}
		}
	})();
})();	

(async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Sales-center-improvements-lite/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Sales-center-improvements-lite' });
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Sales-center-improvements-lite' });
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			}
		}
	} else {
		console.log('brak pliku z informacją o aktualizacji');
	}
})();

async function showMessageFromBackground(message) {
  let tab;
  try {
    tab = await getCurrentTab();
  } catch (error) {
    console.log(error);
  }

  if (tab !== undefined) {
    try {
      sendMessage(tab.id, { action: 'toast', message: message });
    } catch (error) {
      console.log(error instanceof Error ? error.message : error);
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Błąd rozszerzenia Usprawnienia Sales Center Lite', message: message });
      }
    }
  } else {
    if (message.startsWith('Błąd!')) {
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Błąd rozszerzenia Usprawnienia Sales Center Lite', message: message });
      }
    }
  }
  return Promise.resolve(true);
}
